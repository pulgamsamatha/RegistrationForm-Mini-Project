import React from "react";
import RegistrationForm from "./Components/RegistrationForm";

const App = () => {
  return (
    <div>
      <RegistrationForm/>
    </div>
  );
};

export default App;
